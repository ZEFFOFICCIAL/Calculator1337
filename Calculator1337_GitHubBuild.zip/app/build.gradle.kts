plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.zeff.calculator1337"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.zeff.calculator1337"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
