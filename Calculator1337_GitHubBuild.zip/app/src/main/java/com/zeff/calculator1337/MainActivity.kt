package com.zeff.calculator1337

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var display: TextView
    private var expression = ""
    private var showingVault = false
    private val prefs by lazy { getSharedPreferences("vault", MODE_PRIVATE) }
    private val saved get() = prefs.getStringSet("apps", emptySet())?.toMutableSet() ?: mutableSetOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showCalculator()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int = 18): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun column(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(20), dp(18), dp(18))
        setBackgroundColor(Color.rgb(248, 249, 252))
    }

    private fun button(label: String, onClick: () -> Unit, accent: Boolean = false): Button =
        Button(this).apply {
            text = label
            textSize = 20f
            isAllCaps = false
            setTextColor(if (accent) Color.WHITE else Color.rgb(30, 35, 45))
            background = bg(if (accent) Color.rgb(45, 105, 210) else Color.rgb(231, 235, 243), 16)
            setOnClickListener { onClick() }
        }

    private fun showCalculator() {
        showingVault = false
        root = column()
        display = TextView(this).apply {
            text = if (expression.isEmpty()) "0" else expression
            textSize = 38f
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            setTextColor(Color.rgb(25, 31, 42))
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(8), dp(24), dp(8), dp(24))
            minHeight = dp(110)
        }
        root.addView(TextView(this).apply {
            text = "Калькулятор"
            textSize = 20f
            setTextColor(Color.DKGRAY)
        })
        root.addView(display)
        val rows = listOf(
            listOf("7","8","9","÷"),
            listOf("4","5","6","×"),
            listOf("1","2","3","−"),
            listOf("0",".","C","+"),
            listOf("⌫","=")
        )
        rows.forEach { row ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.forEach { key ->
                val b = button(key, { press(key) }, key == "=")
                line.addView(b, LinearLayout.LayoutParams(0, dp(66), 1f).apply {
                    setMargins(dp(4), dp(4), dp(4), dp(4))
                })
            }
            root.addView(line)
        }
        setContentView(root)
    }

    private fun press(key: String) {
        when (key) {
            "C" -> expression = ""
            "⌫" -> if (expression.isNotEmpty()) expression = expression.dropLast(1)
            "=" -> {
                if (expression == "1337") { showVault(); return }
                expression = try { calculate(expression) } catch (_: Exception) { "Ошибка" }
            }
            else -> if (expression.length < 40 && expression != "Ошибка") {
                expression += when (key) { "÷" -> "/"; "×" -> "*"; "−" -> "-"; else -> key }
            }
        }
        display.text = if (expression.isEmpty()) "0" else expression
    }

    // A small recursive-descent evaluator: parentheses, decimals and + - * /.
    private fun calculate(s: String): String {
        if (s.isBlank()) return "0"
        val p = Parser(s)
        val value = p.parse()
        if (!value.isFinite()) throw IllegalArgumentException()
        return if (value % 1.0 == 0.0) value.toLong().toString()
        else String.format(java.util.Locale.US, "%.8f", value).trimEnd('0').trimEnd('.')
    }

    private class Parser(private val s: String) {
        private var i = 0
        fun parse(): Double { val v = expr(); skip(); if (i != s.length) error("tail"); return v }
        private fun skip() { while (i < s.length && s[i].isWhitespace()) i++ }
        private fun expr(): Double {
            var v = term()
            while (true) { skip(); if (i >= s.length) return v
                when (s[i]) { '+' -> { i++; v += term() }; '-' -> { i++; v -= term() }; else -> return v }
            }
        }
        private fun term(): Double {
            var v = factor()
            while (true) { skip(); if (i >= s.length) return v
                when (s[i]) { '*' -> { i++; v *= factor() }; '/' -> { i++; val d=factor(); if (d==0.0) error("zero"); v /= d }; else -> return v }
            }
        }
        private fun factor(): Double {
            skip()
            if (i < s.length && (s[i]=='+' || s[i]=='-')) { val sign=s[i++]; val v=factor(); return if(sign=='-') -v else v }
            if (i < s.length && s[i]=='(') { i++; val v=expr(); skip(); if(i>=s.length || s[i++]!=')') error(")"); return v }
            val start=i
            while (i<s.length && (s[i].isDigit() || s[i]=='.')) i++
            if(start==i) error("number")
            return s.substring(start,i).toDouble()
        }
    }

    private fun showVault() {
        showingVault = true
        root = column()
        root.addView(TextView(this).apply {
            text = "Скрытый список"
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(25,31,42))
            setPadding(0,0,0,dp(12))
        })
        root.addView(button("＋ Добавить приложение", { showPicker() }, true),
            LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(12) })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val packages = saved
        if (packages.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Пока ничего не добавлено. Нажми «Добавить приложение»."
                textSize = 16f; setTextColor(Color.DKGRAY); setPadding(4, dp(12), 4, dp(12))
            })
        }
        packages.forEach { pkg ->
            val pm = packageManager
            try {
                val label = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(8), dp(6), dp(8), dp(6))
                    background = bg(Color.WHITE, 14)
                }
                val icon = ImageView(this).apply { setImageDrawable(pm.getApplicationIcon(pkg)) }
                row.addView(icon, LinearLayout.LayoutParams(dp(42), dp(42)))
                row.addView(TextView(this).apply {
                    text = label; textSize = 17f; setTextColor(Color.BLACK); setPadding(dp(12),0,0,0)
                }, LinearLayout.LayoutParams(0, -2, 1f))
                row.setOnClickListener {
                    val launch = pm.getLaunchIntentForPackage(pkg)
                    if (launch != null) startActivity(launch)
                    else Toast.makeText(this, "Не удалось запустить приложение", Toast.LENGTH_SHORT).show()
                }
                row.setOnLongClickListener {
                    saved.remove(pkg); prefs.edit().putStringSet("apps", saved).apply()
                    showVault()
                    Toast.makeText(this, "Приложение удалено из списка", Toast.LENGTH_SHORT).show()
                    true
                }
                list.addView(row, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(7) })
            } catch (_: Exception) { }
        }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(button("← Назад к калькулятору", { showCalculator() }),
            LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(10) })
        setContentView(root)
    }

    private fun showPicker() {
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        val names = apps.map { pm.getApplicationLabel(it).toString() + "  ·  " + it.packageName }
        val checks = BooleanArray(apps.size) { saved.contains(apps[it].packageName) }
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("Выбери приложения")
            .setMultiChoiceItems(names.toTypedArray(), checks) { _, which, checked ->
                checks[which] = checked
            }
            .setPositiveButton("Сохранить") { _, _ ->
                val selected = apps.indices.filter { checks[it] }.map { apps[it].packageName }.toSet()
                prefs.edit().putStringSet("apps", selected).apply()
                showVault()
            }
            .setNegativeButton("Отмена", null)
            .create()
        dialog.show()
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (showingVault) showCalculator() else super.onBackPressed()
    }
}
